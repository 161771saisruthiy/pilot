package org.cap.dao;

import java.util.List;
import java.util.ListIterator;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.cap.model.Login;

import org.springframework.stereotype.Repository;
@Repository("loginDao")
@Transactional
public class LoginDaoImpl implements ILoginDao{
	@PersistenceContext
	private EntityManager em;
	@Override
	public boolean validateLogin(Login login) {
		System.out.println(login);
		List<Login> loginList=em.createQuery("from Login").getResultList();
		System.out.println(loginList);
		ListIterator<Login> listIterator=loginList.listIterator();
		while(listIterator.hasNext()) {
			Login login1=listIterator.next();
			if(login1.getUserName().equals(login.getUserName())&&login1.getPassword().equals(login.getPassword())) {
				return true;
			}
		}
			
		
		return false;
		
	}

}
