package org.cap.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.cap.model.City;

public class PilotUtil {
public static List<String> getAllCities(){
	List<String> cities=new ArrayList<>();
	cities.add("Chennai");
	cities.add("Tanuku");
	cities.add("Hyderabad");
	cities.add("Banswada");
	return cities;
}

public static List<String> getQualifications() {
	//Map qualifications=new HashMap();
	List<String> qualificationsList = new ArrayList<>();
	qualificationsList.add("Engineer");
	qualificationsList.add("Bsc");
	qualificationsList.add("ME");
	qualificationsList.add("MTech");
	//qualifications.put("qualifications",qualifications);
	return qualificationsList;
}
}
