package org.cap.controller;

import javax.validation.Valid;

import org.cap.model.Aircraft;
import org.cap.model.Pilot;
import org.cap.service.IPilotService;
import org.cap.util.PilotUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;



@Controller
public class PilotController {
	private Pilot p;
private boolean flag;
private String label="Save";
	@Autowired
	private IPilotService pilotService;
	
	@RequestMapping(value="/savePilot",method=RequestMethod.POST)
	public String savePilotDetails(@Valid @ModelAttribute("pilot")Pilot pilot,BindingResult result) {
		if(result.hasErrors())
			return "success";
		else {
		if(this.label.equals("Save")) 
			pilotService.savePilot(pilot);
		else {
			pilotService.updatePilot(pilot);
			this.label="Save";
			this.flag=false;
		}
		return "redirect:/success";
		}
	}
	@RequestMapping(value="/success")
	public String pilotPage(ModelMap map) {
		if(flag) {
			map.addAttribute("pilot", p);
		}else {
		map.addAttribute("pilot",new Pilot());
		}
		map.addAttribute("cities",pilotService.getAllCities());
		map.addAttribute("qualifications",PilotUtil.getQualifications());
		map.addAttribute("pilots",pilotService.getPilotDetails());
		map.addAttribute("label", this.label);
		return "success";
	}
	@GetMapping("/delete/{pilotId}")
	public String getPilot(@PathVariable("pilotId") Integer pilotId) {
		pilotService.deletePilot(pilotId);
		return "redirect:/success";
	}
	@GetMapping("/update/{pilotId}")
	public String updatePilot(@PathVariable("pilotId") Integer pilotId) {
		this.flag=true;
		this.label="Update";
	  p=pilotService.getPiotById(pilotId);
		//pilotService.updatePilot(pilotId, p);
		return "redirect:/success";
	}
	@GetMapping("certificate/{pilotId}")
	public String addPilotCertification(@PathVariable("pilotId") Integer pilotId,ModelMap map) {
		
	  //p=pilotService.getPiotById(pilotId);
		map.addAttribute("pilot",new Pilot());
		map.addAttribute("aircraft",new Aircraft());
		map.addAttribute("pilots",pilotService.getPilotDetails());
		map.addAttribute("aircraftIds",pilotService.getOtherAircraft(pilotId));
		return "certificate";
		
		
	}
	@RequestMapping(value="certificate/addcertification/{pilotId}",method=RequestMethod.POST)
	public String validateLogin(
			@PathVariable("pilotId")Integer pilotId,
			@RequestParam("aircraft")String aircraftId,
			ModelMap map) {
	        pilotService.addPilotCertification(pilotId,aircraftId);
		
		return "redirect:/success";
	}
	@RequestMapping(value="/certificate")
	public String certificatePage(ModelMap map) {
		map.addAttribute("pilot",new Pilot());
		map.addAttribute("aircraft",new Aircraft());
		map.addAttribute("pilots",pilotService.getPilotDetails());
		map.addAttribute("aircraftIds",pilotService.getAircraft());
		return "certificate";
	}
}
